# Document Extraction Standards

Faithfully turning a source document into clean text plus structured metadata, with no interpretation.

---

## GUARD: extract only what is in the source

Do not add, infer, correct, complete, summarize, or interpret. Every extracted word, number, date, and label must exist in the document in front of you. If something is illegible, missing, or points to another document, flag it; do not fill it in. The examples in this file are generic; never carry their content into an extraction.

---

## HOW TO USE THIS FILE

The core extraction rules live in `document-extraction-standards.md`. They always apply. This file adds conditional handling (Sections H–K below) on top of those core rules, and routes each document to the conditional sections it needs. Answer the five questions in the decision section, add the sections each answer calls for, then extract following the core standards plus every applicable conditional section. In your final output, state which conditional sections you applied.

---

## CORE STANDARDS

The core standards are the whole of `document-extraction-standards.md`: methodology, what to flag, what not to do, special cases, output structure, quality assurance, and delivery. Apply that file in full to every extraction. Do not restate or paraphrase it here; read it directly.

---

## CONDITIONAL STANDARDS (H–K, apply when the decision section calls for them)

### H. Formatting, layout and visual elements
When charts, diagrams, tables, images, or graphs are essential to meaning: preserve table structure exactly (rows, columns, headers); describe charts and diagrams factually, without interpreting them; preserve visual hierarchy; note page layout where meaning depends on it.

### I. Handling uncertainty and limitations
When the source is scanned or OCR'd, unclear, corrupted, machine-translated, non-English, or uses unfamiliar notation, or when you compare versions: flag every uncertain, unclear, or illegible passage and its location; note whether OCR was used and its confidence; note if the text appears machine-translated; do not guess or correct; state limitations before you begin. Version subsection: extract each version separately; record version numbers and dates; flag amendments and how they change the original; never merge versions without noting the source.

### J. Scope boundaries and edge cases
When the document references external material, includes appendices, or has blank or TBD sections: flag all references to documents not provided; extract appendices and exhibits separately, clearly labeled; note blank sections and TBD areas; preserve headers, footers, and boilerplate even when repetitive.

### K. Document metadata and provenance
When the source is scanned, photographed, or an image PDF without digital text: record how the document was obtained, its source quality, and page count; record the scan or retrieval date; flag OCR use and confidence level.

---

## DECISION SECTION: WHICH CONDITIONAL SECTIONS APPLY

Answer these five questions. For each YES, add the sections shown.

### Question 1: Source type
Is the document scanned, photographed, or extracted from an image or PDF without digital text?
- YES: add Section I (flag OCR confidence, illegible sections, encoding problems) and Section K (capture provenance, page count, OCR confidence).
- NO: continue.

### Question 2: Visual content
Does the document include charts, diagrams, tables, images, or graphs essential to understanding?
- YES: add Section H.
- NO: continue.

### Question 3: External references and scope
Does the document reference external documents, appendices, or exhibits, or leave sections blank or TBD?
- YES: add Section J.
- NO: continue.

### Question 4: Source quality and clarity
Is the document unclear, corrupted, machine-translated, non-English, or full of unfamiliar specialized notation?
- YES: add Section I.
- NO: continue.

### Question 5: Version comparison
Are you comparing two or more versions, or extracting a document with track changes or amendments?
- YES: add Section I (version subsection).
- NO: core standards Core only.

---

## ROUTING TABLE

| Source | Visual | External | Unclear | Versions | Apply |
|--------|--------|----------|---------|----------|-------|
| Digital | No | No | No | No | Core |
| Digital | Yes | No | No | No | Core + H |
| Digital | No | Yes | No | No | Core + J |
| Digital | No | No | Yes | No | Core + I |
| Scanned | Any | Any | Any | Any | Core + H + I + K |
| — | — | — | — | Yes | Core + I (version subsection) |
| Any | Yes | Yes | Any | Any | Core + H + J (+ I if unclear) |

Key: H formatting and layout; I uncertainty; J scope boundaries; K provenance.

---

## GENERIC EXAMPLES

These show how to route documents. Company names are omitted on purpose; describe documents by type and property only.

- A clean digital terms-of-service web page, text only, that references a separate privacy policy and additional terms not included.
  Answer: Digital, No, Yes, No, No. Apply: Core + J (flag the external references).

- A scanned contract with handwritten notes, tables of terms, signature blocks, and attached exhibits.
  Answer: Scanned, Yes, Yes, Yes, No. Apply: Core + H (preserve tables and layout) + I (flag handwriting) + J (handle exhibits) + K (record source and scan quality).

- A digital technical specification with process diagrams that references an appendix of interface documentation.
  Answer: Digital, Yes, Yes, No, No. Apply: Core + H (preserve diagram structure) + J (handle the appendix reference).

- Two digital versions of one agreement, compared side by side, text only, no external references.
  Answer: Digital, No, No, No, Yes. Apply: Core + I (version subsection).

---

## WHEN UNSURE

When in doubt, add the section. Following a standard you did not need costs less than a silent gap. If the document might be machine-translated, add I. If layout might carry meaning, add H. If it might reference something external, add J.

---

## WORKFLOW

1. Answer all five questions.
2. Find the combination in the routing table.
3. Apply core Sections Core plus every added section.
4. Before extracting, review the added sections and confirm which apply.
5. Extract following every applicable section.
6. In the output, state which sections were applied and mark the extraction partial if any binding content sits outside it.
