# Document Analysis Guidelines

Turning an extracted document into plain-language explanation without interpretation or speculation.

---

## GUARD: facts come only from the document under analysis

Every quote, number, dollar figure, section reference, defined term, date, and party name in your output must come from the document you are analyzing right now. The examples in this file are generic and illustrative. Never copy their content, and never carry facts, numbers, or citations from any previous document, into a new analysis. If a figure or clause is not in the current document, it does not appear in your output.

---

## A. WHAT ANALYSIS IS (AND ISN'T)

### Analysis IS:
- Explanation in plain language: translating legal or technical language into words a layman understands.
- Structural description: showing who has what rights, where asymmetries exist, what is missing.
- Pattern identification: flagging conflicts, contradictions, one-sided provisions, undefined terms.
- Stakeholder-focused summary: explaining what a document means for specific use cases or parties.
- Highlighting gaps: noting what the document does not address.
- Flagging structural signals: pointing out provisions that are unusual, absolute, or heavily weighted one direction.

### Analysis IS NOT:
- Legal interpretation: explaining what provisions "really mean" under contract law or precedent.
- Enforceability assessment: judging whether clauses are enforceable or how a court would read them.
- Speculation about intent: guessing why a party included a provision or what they meant.
- Predicting consequences: saying what will happen if you violate a provision or what remedies exist.
- Advice: telling the reader what to do or what to decide.
- Moral judgment: calling a provision "unfair," "unreasonable," or "predatory." You may flag it as one-sided or absolute; you may not judge its fairness.

---

## B. DIMENSIONS OF ANALYSIS

Pick one or more approaches based on the document and intended use.

### 1. Journey-Based Analysis
Break the document into specific user journeys or scenarios.

Example journeys for a service agreement:
- Ownership of the provider's IP versus ownership of things you create with it.
- Feedback or suggestions you give the provider.
- Indemnities and liability when using the service.
- How disputes are resolved.

When to use: service agreements, terms of use, partnership contracts, API terms.
Benefit: answers "what does this mean for my situation?"

### 2. Stakeholder-Based Analysis
Explain the document from different viewpoints.

Example stakeholders:
- User or customer: what are my rights and obligations?
- Service provider: what are my protections and liabilities?
- Third parties: am I protected if someone sues the provider?

When to use: multi-party agreements, employment contracts, partnership terms.
Benefit: shows how provisions affect different people.

### 3. Provision-by-Provision Analysis
Go through major sections and explain each in plain language.

Structure: section heading; what it says (plain language); who it applies to; what you must do, what they claim, what you get; notable details or qualifiers.

When to use: comprehensive reviews where every provision matters.
Benefit: thorough; nothing missed.

### 4. Risk & Asymmetry Analysis
Focus on imbalances and what the document allows.

Document: one-sided rights (one party can act without consent, the other cannot); imbalanced obligations (one party bears more risk); absolute versus qualified statements; liability caps and what they cover.

When to use: contracts where power imbalances matter.
Benefit: highlights the weighted provisions.

### 5. Structured Comparison Analysis
Compare the document against a template, a standard, or another version.

Structure: what the document includes that is standard; what it leaves out or restricts; how it differs from a stated baseline; where it is more or less favorable than the other version.

When to use: evaluating against a baseline.
Benefit: shows what is unusual or notable.

You can combine approaches.

---

## C. HOW TO STRUCTURE ANALYSIS

### Step 1: Identify the Stakeholder & Purpose
Know who the analysis is for, what decision they are making, and what they need to know.

### Step 2: Choose Your Approach
Pick from Section B based on the document and purpose. You may combine approaches.

### Step 3: Extract Key Information
From the extracted document, pull out: structural facts (who owns what, who has what rights); obligations; restrictions; protections; liabilities and caps; termination and survival; asymmetries; undefined terms; contradictions; gaps.

### Step 4: Translate to Plain Language
Take each fact and explain it simply. Generic examples of the translation move (fill placeholders from the current document only):

| Legal Language | Plain Language |
|---|---|
| "[Provider] grants you a limited, non-exclusive, non-transferable, non-sublicensable, revocable license to access and use the [product]" | You can use it for yourself. You cannot sell access, share it, or transfer it, and they can revoke it at any time. |
| "the aggregate liability of [Provider] to you for all claims is limited to $[amount]" | Whatever goes wrong, the most they will owe you is $[amount] in total, even if your loss is far larger. |
| "you will defend and indemnify [Provider] against every claim brought by a third party" | If anyone sues them over something you did, you pay their legal fees and any damages. |

### Step 5: Organize Into Sections
Structure by journey, stakeholder, or risk theme, not by the document's own section order. A generic structure for a service agreement: what you own versus what they own; what they promise and do not promise; how much they can owe you; how disputes get resolved; what happens if things change; key asymmetries.

### Step 6: Add Context & Caveats
After each major point add: what this means for you (plain-language consequence); when it applies (scope or conditions); what is missing (gaps or undefined terms); how it compares to a standard, only if you know the baseline.

---

## D. WHAT NOT TO DO

### 1. Do Not Interpret
- Not "this means they can shut down your account without warning." Instead: "the document says they can terminate your access at any time without notice."
- Not "this clause is designed to protect them from liability." Instead: "this clause limits their liability to $[amount]."

### 2. Do Not Advise
- Not "you should not sign this," "this is a bad deal," "you need to negotiate this clause."
- Instead: "this provision gives them the right to..." and "this differs from [stated standard], which..."

### 3. Do Not Judge
- Not "this unfair clause shows they don't care about users," "this is a predatory practice," "this is meant to exploit you."
- Instead: "this provision favors [party]" (state the asymmetry); "this provision is absolute with no qualifier" (state the fact); "this contradicts Section [X]" (flag the conflict).

### 4. Do Not Speculate
- Not "they probably mean...," "in practice this likely...," "courts usually read this as..."
- Instead: "the document states...," "the document does not address...," "this term is not defined in the document."

### 5. Do Not Fill Gaps
- Not "since they don't define '[term],' it probably means..."
- Instead: "the term '[term]' is not defined in the document."

### 6. Do Not Rewrite the Document
- Do not produce a "simplified" version that reorganizes or reinterprets.
- Explain what each section says in plain language, preserving meaning.

---

## E. IDENTIFYING PATTERNS & ASYMMETRIES

Each pattern below carries a generic example. Replace bracketed placeholders with content from the current document only.

### One-Sided Rights
One party can act unilaterally; the other cannot; or a right is granted to one party but not the other.
Example: "[Provider] can assign the agreement to anyone at any time without your consent; you cannot assign without their written permission."
Flag as: "Asymmetric [right] rights."

### Asymmetric Obligations
One party bears more risk, cost, or work than the other.
Example: "You indemnify [Provider]; [Provider] does not indemnify you."
Flag as: "[Obligation] is one-way."

### Absolute vs. Qualified Statements
Absolute statements ("will have no liability," "you cannot") are stronger than qualified ones ("to the fullest extent permitted by law," "except as permitted by law").
Example: "'[Provider] will have no liability for [event]' (absolute) versus a liability cap stated 'to the fullest extent permitted by law' (qualified)."
Flag as: "Absolute statement without legal qualifier."

### Undefined Terms Carrying Weight
Words that control rights or obligations, are used more than once, and are not defined.
Example: "'[term]' is used to define what you may not do but is never defined."
Flag as: "Undefined term with legal weight."

### Contradictions
Two sections that state opposing things, or a cap that conflicts with a separate provision.
Example: "Section [X] caps liability at $[amount]; Section [Y] states a minimum recovery of $[higher amount]. The document does not reconcile them."
Flag as: "Direct conflict between Section [X] and Section [Y]."

### Missing Protections
A right or scenario that a reader would expect the document to address, and it does not.
Example: "The document does not state who owns work you create using the service."
Flag as: "Document does not address [subject]."

### Scope Limitations
Provisions that apply only to certain people or situations, or that carve out exceptions.
Example: "Applies only to residents of [region]"; "access from outside [country] is prohibited"; "arbitration excludes small-claims and IP-infringement disputes."
Flag as: "Applies only to [X]" or "Does not apply to [Y]."

---

## F. OUTPUT STRUCTURE

### 1. Opening Statement
State the document type, purpose, and who it is for.
Generic form: "This is [Provider]'s [document type] for [audience]. It governs [scope]."

### 2. Summary of Key Provisions
In three to five sentences, state the most important points, drawn from the current document.
Generic form: "You get [permission/scope]. [Provider] owns [what]. [Feedback/data] is treated as [how]. Liability is [capped/limited] at $[amount]. Disputes go to [forum]."

### 3. Analysis by Journey/Theme
Use the structure you chose. For each section: heading; plain-language explanation; key provisions (quote briefly or cite section numbers from the current document); notable details (qualifiers, conditions, time limits); asymmetries or conflicts if relevant; what is missing.

### 4. Flagged Items Section
List all: conflicts (cite both sections); undefined terms (name them and where used); asymmetries (state which way they lean); absolute statements (name the provisions with no qualifier); missing information (what the document does not address).

### 5. Caveats & Limitations
State what the analysis did not cover (no legal interpretation, no enforceability assessment, no prediction), what assumptions were made (layman reader, general understanding), and what the analysis is not (advice, interpretation, prediction, judgment).
Generic form: "This analysis explains what the document says, not what it means legally or what will happen if you violate it. It is not legal advice and does not predict how a court would read these provisions."

---

## G. QUALITY ASSURANCE BEFORE DELIVERY

### 1. Source-Fidelity Check
- Every quote, number, dollar figure, section citation, defined term, date, and party name appears in the current document.
- No content from the examples in this file, and none from any prior document, has entered the output.

### 2. Accuracy Check
- Every plain-language explanation matches what the extracted document says.
- No interpretation, advice, or moral language has crept in.

### 3. Completeness Check
- All major sections are covered.
- All journeys or stakeholders relevant to the purpose are addressed.
- All conflicts, undefined terms, and asymmetries are flagged.

### 4. Plain Language Check
- A person without legal training can understand every explanation.
- No unnecessary jargon remains; complex provisions are broken into simpler pieces.

### 5. No Advice / No Judgment Check
- Scan for "you should," "you must," "you need to," "don't," and for "unfair," "unreasonable," "predatory."
- Remove all prescriptive and all judgment language; replace with "the document says..." or "this provision..."

---

## H. DELIVERY & CONTEXT

### 1. Audience
State who the analysis is written for, and adjust detail and language accordingly.

### 2. Purpose
State what decision or question the analysis serves.

### 3. Scope
State what the analysis covers (what the document says, plain-language explanation, flagged conflicts) and what it does not (enforceability, likely outcomes, court interpretation, advice).

### 4. Format
Choose based on audience: narrative; structured (headings, scannable); tabular (key provisions in a table); checklist (key facts as bullets).

### 5. Length
Tailor to purpose: executive summary (key points only); standard analysis (major provisions explained); deep analysis (every provision covered).

---

## I. GENERIC WORKED EXAMPLES

These are templates. Every bracketed value is a placeholder to fill from the current document only.

### Journey-Based
Journey: things you create with the service.
- What the document says: [state whether it addresses ownership of your creations, or that it does not].
- Why this matters: [plain-language consequence for the reader's use case].
- Missing: [name what the document would need to state and does not].

Journey: feedback you give the provider.
- What the document says: [state how feedback is treated].
- Plain language: [translate].
- Condition: [state what the feedback clause applies to].

### Risk & Asymmetry
Asymmetry: liability.
- They owe you: [cap and section].
- You owe them: [indemnity scope and section].
- The imbalance: [state which exposure is capped and which is open-ended].

Asymmetry: assignment.
- They can: [state their assignment right and section].
- You can: [state your restriction and section].
- The imbalance: [state the effect].

### Provision-by-Provision
Section [X]: [heading].
- What it says: "[short quote from the current document]".
- Plain language: [translate].
- Scope: [who and what it applies to].
- Notable detail: [qualifier, condition, or time limit].

---

## J. DOCUMENT TYPES & ANALYSIS APPROACH

- Service terms / terms of use: journey-based or risk & asymmetry. Focus: what each party can and cannot do, and the limits.
- Employment contracts: stakeholder-based or risk & asymmetry. Focus: employee obligations, employer protections, gaps.
- Partnership agreements: provision-by-provision or comparison. Focus: splits, decisions, exit.
- Privacy policies: journey-based or risk & asymmetry. Focus: what data is collected, who it is shared with, what control you have.
- API terms: risk & asymmetry or comparison. Focus: rate limits, uptime, liability, unilateral changes.
- Investment agreements: provision-by-provision or comparison. Focus: valuation, rights, exit scenarios.

---

## SUMMARY

Analysis is translation, plus pattern-finding, plus flagging.
1. Translate legal language to plain English.
2. Identify patterns: asymmetries, conflicts, gaps, undefined terms.
3. Flag issues without interpreting consequences.
4. Organize by journey, stakeholder, or risk, not by document structure.
5. Deliver with clear caveats about what the analysis is not.
6. Confirm every fact in the output comes from the current document.
