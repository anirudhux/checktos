# Document Extraction & Review Standards (Comprehensive)

## GUARD: extract only what is in the source

Reproduce what the document says; add nothing. Every quote, number, date, section reference, defined term, and entity name in your output must come from the document under extraction. Do not interpret, correct, complete, or generalize. The examples in this file are generic and illustrative; never carry their content into an extraction.

---

## A. EXTRACTION METHODOLOGY

### 1. Source Handling
- For URLs: Fetch and extract the current version. Note the retrieval date.
- For uploaded files: Read the file as provided. Do not assume alternative versions exist.
- For multi-page documents: Extract every page, including headers, footers, and footnotes that appear on every page.
- If a document references external documents (linked terms, privacy policies, exhibits), note the reference exactly as stated. Do not assume access or attempt to fetch unless explicitly instructed.
- If a document includes hyperlinks, capture the URL as it appears in the text.

### 2. Structural Preservation
- Maintain the document's original section numbering, hierarchy, and nesting.
- If sections are lettered, numbered, or bulleted in the original, preserve that exact structure.
- If subsections use different numbering schemes (Roman numerals, lowercase letters), reproduce them as they appear.
- Do not reorganize or reorder for "clarity"; report the structure as presented.
- Capture all headings, subheadings, and section titles verbatim.

### 3. Text Extraction Standards
- Quote provisions in full. If a provision spans multiple paragraphs, include all paragraphs.
- Preserve capitalization, punctuation, and emphasis (bold, italics, ALL CAPS) as it appears.
- If text appears in multiple forms (once in ALL CAPS in a preamble, then in normal case in the actual section), report both instances noting where each appears.
- Do not convert abbreviations to full form. Keep an entity name such as "[Entity Name], Inc." exactly as stated, not expanded to "[Entity Name], Incorporated."
- If the document uses shorthand references (e.g., "Section 3(c)" or "hereinafter 'the Site'"), quote these exactly as written.

### 4. Metadata Capture
- Document title/heading
- Last updated/revised date
- Version number (if present)
- Entity name and contact information as stated
- Copyright or attribution lines
- Page count (if relevant)
- Any disclaimers in header/footer (e.g., "DRAFT—NOT FOR DISTRIBUTION")
- URLs for referenced policies or external links
- Effective date (if different from last updated)

### 5. Defined Terms
- When a document defines a term in quotes or parentheses, capture the exact definition.
- Note if a term is used before it is defined.
- Note if a term is defined multiple times or differently in different sections.
- Flag if a term is used but never explicitly defined.

---

## B. WHAT TO FLAG (AND HOW)

### 1. Contradictions
- Report contradictions as pairs: quote both conflicting provisions with section numbers.
- Do not interpret which should win.
- Note if the document contains any language attempting to resolve the contradiction (e.g., "notwithstanding Section X").
- If one section explicitly states an exception to another, report this as stated; it is not necessarily a contradiction.

### 2. Undefined or Vague Terms
- Flag terms that appear to carry legal weight but are not defined in the document.
- Do not define them using external legal knowledge or common usage.
- Do not assume a term is clear because it seems obvious.
- Examples: "unauthorized," "misuse," "reasonable," "material," "timely," "good faith," "commercially reasonable."
- Note if a term is defined in one section but used differently in another section.

### 3. Cross-References
- Capture all cross-references exactly as written (e.g., "Section 12(b)", "as defined in Section 4").
- Verify that every cross-reference points to an actual section in the document.
- Flag if a cross-reference points to a section that does not exist or is named differently.
- Flag if a section refers to another section that should clarify or modify it, but does not.
- Note forward references (referencing a section before it appears) and backward references.

### 4. Temporal Ambiguities
- Flag provisions that reference time but do not specify the starting point (e.g., "within 30 days" from when?).
- Flag provisions that state different rules apply "at the time" something occurred vs. "currently" vs. "going forward."
- Note if a document states terms can change and specifies which version of terms governs disputes.
- Flag if survival clauses exist and which sections survive termination.
- Note any "grandfathering" provisions that preserve old terms for existing users.

### 5. Scope Limitations
- Note all provisions that apply conditionally (e.g., "if you are a [region] resident," "for claims under $[amount]").
- Flag provisions that state they do NOT apply to something specific.
- Note any geographic, jurisdictional, or status-based limitations.
- Flag if limitations are stated positively ("applies to") vs. negatively ("does not apply to").

### 6. Absolute vs. Qualified Statements
- Flag statements that use absolute language without qualification (e.g., "we will have no liability" vs. "we will not be liable to the extent permitted by law").
- Note where a provision claims to override law or local regulations.
- Flag provisions that state they apply "to the fullest extent permitted by law" vs. unconditionally.

### 7. One-Sided Provisions
- Flag rights, obligations, or protections that apply to one party but not the other.
- Example: "We may assign these terms at any time without consent; you may not assign without our consent."
- Flag asymmetric notice requirements, opt-out procedures, or termination rights.

### 8. Missing Information
- Flag if a section references a procedure, form, or address that should be included but is not.
- Flag if a document says "as more fully described in [exhibit]" but the exhibit is not present.
- Flag if required information is left blank or marked "TBD."

### 9. Incorporation by Reference
- Flag every phrase incorporating external documents ("including the Privacy Policy," "as defined in Additional Terms").
- Note which documents are incorporated.
- Note if those documents are linked, attached, or merely referenced by name.
- Flag if an incorporated document is not accessible from the extraction.

---

## C. WHAT NOT TO DO

### 1. Do Not Interpret
- Do not explain what a provision "means in practice."
- Do not apply contract law, statutory interpretation, or legal precedent.
- Do not speculate about intent or likely enforcement.
- Do not offer opinions on reasonableness, fairness, or enforceability.

### 2. Do Not Fill Gaps
- Do not assume standard legal meanings for undefined terms.
- Do not infer missing provisions from patterns in the document.
- Do not explain what "probably" happens under common law if the document is silent.

### 3. Do Not Rewrite
- Do not modernize language or translate legal jargon into plain English.
- Do not split long sentences for readability.
- Do not remove redundancy or "clean up" the text.
- Do not correct grammar, spelling, or punctuation even if it appears to be an error.

### 4. Do Not Omit
- Do not skip sections because they seem "standard" or "boilerplate."
- Do not leave out disclaimers, preambles, or introductory language.
- Do not abbreviate long provisions.
- Do not exclude definitions because you think they are obvious.

### 5. Do Not Reorganize
- Do not reorder sections for logical flow.
- Do not group related ideas from different sections together.
- Do not create a "summary" that reorganizes the document's structure.

### 6. Do Not Combine or Generalize
- Do not merge similar provisions into one statement.
- Do not say "the document prohibits X" when it actually lists five specific forms of X.

---

## D. HANDLING SPECIAL CASES

### 1. Layered Documents (Terms + Privacy Policy + Addenda)
- Extract each document separately if provided.
- If one document incorporates another by reference, note this relationship.
- If an incorporated document is not provided, state that it is referenced but not available for extraction.
- Do not attempt to infer the content of missing incorporated documents.

### 2. Conditional Provisions (If/Then Structures)
- Capture the full condition and the full consequence.
- If conditions are nested or complex, preserve the nesting in the extracted text.
- Flag if the same condition appears in multiple sections with different consequences.

### 3. Lists Within Provisions
- If a provision contains a list (especially with subparts like (i), (ii), (iii)), extract the entire list with all items.
- Preserve the list structure and numbering/lettering.
- Do not omit list items because they seem redundant or similar to previous items.

### 4. Exceptions and Carve-Outs
- When a provision states an exception (e.g., "Except as provided in Section X"), extract both the main rule and the exception.
- Verify the exception actually exists in the referenced section.
- Flag if an exception is claimed but the referenced section does not contain it.

### 5. Mutual vs. One-Directional Obligations
- Clearly indicate if an obligation applies to both parties or only one.
- Preserve the exact language (e.g., "You agree to..." vs. "We agree to...").
- Flag if the same concept is stated differently for each party.

### 6. Survival Clauses
- Extract the exact list of sections that survive termination.
- Verify each cited section actually exists.
- Flag if a provision claims to survive but termination is not defined in the document.

### 7. Dollar Amounts and Numerical Thresholds
- Report every number, dollar amount, and threshold exactly as stated.
- Do not round or convert (e.g., if it says "$10,000 USD," do not say "ten thousand dollars").
- Flag if different thresholds apply in different contexts (e.g., different caps for different claim types).
- Note if a threshold is stated as "or less" vs. "or more" vs. "up to."

---

## E. OUTPUT STRUCTURE

### 1. Organization
- Present extraction in the document's original order.
- Use section headings that match the source.
- Use subsection labels that match the source.

### 2. Quotation Format
- Use quotation marks for verbatim text from the document.
- Use [brackets] to indicate editorial additions (e.g., "[as defined in Section 4]" where clarifying a reference).
- Do not use [sic] unless the document contains an obvious error that is material to understanding.

### 3. Metadata Section
- Include a metadata section at the start listing document name, date, entity, URLs, etc.

### 4. Flags and Conflicts Section
- Create a separate section listing all flagged items.
- Organize flags by category: Contradictions, Undefined Terms, Cross-Reference Issues, Temporal Ambiguities, etc.
- For each flag, include the exact text from the document and the section number.

### 5. Index of Defined Terms
- Create an index of all formally defined terms (words in quotes or parentheses given definitions).
- Note the section where each is defined.
- Note if a term is used before being defined or defined multiple times.

### 6. Cross-Reference Map
- List every cross-reference in the document and verify it points to an actual section.
- Note broken or ambiguous references.

---

## F. QUALITY ASSURANCE BEFORE DELIVERY

### 1. Completeness Check
- Verify every section is represented (no missing sections).
- Verify every subsection is represented.
- Verify no material text was omitted.

### 2. Accuracy Check
- Spot-check quotations against the source (especially long provisions).
- Verify section numbers and references match the original.
- Verify no inadvertent paraphrasing has occurred.

### 3. Conflict Check
- Re-read flagged conflicts to confirm they are genuine contradictions, not just similar language.
- Verify a provision that actually resolves the conflict has not been misread.

### 4. Completeness of Flags
- Review the full document one more time to confirm no undefined terms, contradictions, or cross-reference issues were missed.

### 5. Format Check
- Verify metadata is complete.
- Verify quotations are clearly marked.
- Verify section structure mirrors the source.
- Verify the flags section is organized and easy to reference.

### 6. Source-Fidelity Check
- Confirm every quote, number, date, section citation, defined term, and entity name in the output appears in the current document.
- Confirm no content from the examples in this file, and none from any prior document, has entered the output.

---

## G. DELIVERY AND CONTEXT

### 1. Intended Use
- If extraction is for legal review, publication, or a court filing, note this.
- Extraction standards may be even stricter for legal use (no room for interpretation gaps).

### 2. Limitations Statement
- If a document cannot be fully extracted (corrupted, image-heavy, unclear OCR), state this clearly.
- Do not attempt to work around technical limitations; flag them.

### 3. Version and Date
- Note the date the extraction was performed.
- Note the version/date of the source document.
- If a document is updated while work is in progress, note which version was extracted.
