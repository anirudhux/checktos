# Document Analysis - Decision Tree

Use this to choose which analysis approach(es) to apply to an extracted document.

---

## GUARD: this file only picks the approach

This tree decides how to analyze, not what the document says. Pull every fact, number, quote, and party name from the document under analysis, never from the examples here. The examples are generic and illustrative.

---

## QUICK START

Answer three questions. The tree shows which analysis approach(es) fit best.

---

## QUESTION 1: Document Type

What kind of document are you analyzing?

- Service Agreement / Terms of Use / API Terms
  - Recommended: Journey-based or Risk & Asymmetry
  - Why: these need "what does this mean for me?" and "what are the dangers?"
- Employment Contract / Partnership Agreement
  - Recommended: Stakeholder-based or Risk & Asymmetry
  - Why: multiple parties with conflicting interests; asymmetries matter
- Privacy Policy / Data Policy
  - Recommended: Journey-based (tracking data flows)
  - Why: people want to know "what data do they collect?" and "who can see it?"
- Investment Agreement / Cap Table Document
  - Recommended: Provision-by-Provision or Comparison
  - Why: every detail matters; usually compared to term sheets
- Regulatory / Compliance Document
  - Recommended: Provision-by-Provision
  - Why: obligations are often complex and interdependent
- Procedure Manual / Handbook / Guide
  - Recommended: Provision-by-Provision or Structured Comparison
  - Why: readers need to understand their obligations
- Contract with Multiple Versions
  - Recommended: Comparison (old vs. new)
  - Why: focus on what changed

---

## QUESTION 2: Audience & Purpose

Who is reading this analysis and what do they need to decide?

- Founder / Executive: "Should we use or sign this?"
  - Approach: Risk & Asymmetry + Journey-based
  - Focus: key dangers, one-sided provisions, missing protections
  - Length: executive summary (2-3 pages) or full analysis (5-10 pages)
- Team Member / Employee: "What does this mean for me?"
  - Approach: Journey-based or Stakeholder-based
  - Focus: your rights, your obligations, what can change
  - Length: standard (5-10 pages)
- Lawyer / Contract Professional: "Complete understanding for negotiation"
  - Approach: Provision-by-Provision + Comparison
  - Focus: every detail, all asymmetries, all conflicts
  - Length: deep analysis (15+ pages)
- General Audience: "What is this policy about?"
  - Approach: Journey-based or structured sections
  - Focus: plain language, no jargon, no advice
  - Length: standard or executive (3-8 pages)
- Investor / Due Diligence: "What are the legal risks?"
  - Approach: Risk & Asymmetry + Provision-by-Provision
  - Focus: liabilities, obligations, unusual terms, missing standard protections
  - Length: full analysis (10+ pages)

---

## QUESTION 3: Analysis Scope

How much detail does the audience need?

- "Just the key points"
  - Approach: Journey-based or Risk & Asymmetry
  - Output: executive summary (1-3 pages)
  - Format: bullet points or short paragraphs
  - Coverage: the 2-3 most important journeys or risks
- "Important details plus context"
  - Approach: Journey-based plus flagged asymmetries
  - Output: standard analysis (5-10 pages)
  - Format: sections with headings, key points highlighted
  - Coverage: all major journeys or stakeholders
- "Everything, thoroughly"
  - Approach: Provision-by-Provision
  - Output: deep analysis (15+ pages)
  - Format: full sections with detailed explanations
  - Coverage: every provision explained
- "How does this compare?"
  - Approach: Comparison
  - Output: 5-15 pages depending on complexity
  - Format: side-by-side or section-by-section
  - Coverage: what is standard versus unusual

---

## ROUTING TABLE

| Document Type | Audience | Scope | Approach(es) | Length |
|---|---|---|---|---|
| Service Terms | Founder | Key points | Journey + Risk | 2-3 pages |
| Service Terms | Founder | Full detail | Journey + Risk + Provision | 8-10 pages |
| Service Terms | General | Key points | Journey | 2-3 pages |
| Employment | Executive | Key points | Stakeholder + Risk | 3 pages |
| Employment | Employee | Full detail | Stakeholder + Journey | 5-8 pages |
| Privacy Policy | General | Key points | Journey (data flows) | 2-3 pages |
| Investment | Lawyer | Full detail | Provision + Comparison | 15+ pages |
| Contract (new vs. old) | Founder | Compare | Comparison | 5-8 pages |
| Compliance | Team | Full detail | Provision | 10-12 pages |
| API Terms | Engineer | Key points | Journey + Risk | 2-5 pages |

---

## GENERIC EXAMPLES

Every bracketed value is a placeholder to fill from the current document only. Descriptions name document type and audience, not real companies.

### Example 1: Service Terms, founder deciding whether to build
- Document: service terms
- Audience: technical founder
- Purpose: decide whether to build on the service
- Scope: key risks only
- Approach: Journey-based plus Risk & Asymmetry
- Length: 3-4 pages
- Output:
  1. Summary (one paragraph)
  2. Journeys with their risks (about one page each): what you create with the service; feedback you give the provider; liabilities and losses; how disputes resolve
  3. Key asymmetries flagged (half page)
  4. Scope line: what the analysis covered and did not cover (half page). State scope, not a recommendation.

### Example 2: Employment contract, new hire
- Document: employment agreement
- Audience: job candidate
- Purpose: understand obligations and protections
- Scope: full detail
- Approach: Stakeholder-based (your rights versus employer rights) plus Journey-based (compensation, termination, IP, non-compete)
- Length: about 8 pages
- Output: summary; compensation journey; IP journey; termination journey; non-compete and confidentiality journey; asymmetries; caveats

### Example 3: Privacy policy, regulatory audit
- Document: privacy policy
- Audience: compliance or legal team
- Purpose: check against a named regulation
- Scope: complete, every detail
- Approach: Journey-based (collection to storage to sharing to deletion) plus Comparison (against the regulation's requirements)
- Length: 12-15 pages
- Output: data collection journey; retention journey; sharing journey; user-rights journey; comparison to the regulation (required versus stated); gaps

### Example 4: Contract redline, version comparison
- Document: a term sheet, version 1 versus version 2
- Audience: the reviewing lawyer
- Purpose: understand what changed
- Scope: every detail
- Approach: Comparison (what changed) plus Provision-by-Provision (impact)
- Length: 15+ pages
- Output: changes summary; deep comparison of each change (old versus new, what it affects, whether it is standard); new or unusual provisions absent from version 1; provisions that disappeared; asymmetries introduced by the changes

---

## DECISION WORKFLOW

1. Answer the three questions.
2. Find the combination in the routing table.
3. Identify the primary approach plus any secondary approaches.
4. Determine length and output format.
5. Plan the structure (journeys, stakeholders, or provisions to cover).
6. Before delivering, check: does it answer the audience's actual question; is it in language they will understand; does it avoid advice, interpretation, and judgment; does it flag all conflicts and asymmetries?

---

## IF UNSURE

Default to Journey-based plus Risk & Asymmetry. It answers "what does this mean for me?" (journey), surfaces what could go wrong (risk), and shows unequal treatment (asymmetry), which fits most documents and audiences. If it does not feel right after the three questions, reconsider the audience; the approach depends more on who is reading than on document type.

---

## FORMAT RECOMMENDATIONS BY APPROACH

- Journey-Based: narrative or structured sections. Structure: journey name, what the document says, what it means, what is missing.
- Stakeholder-Based: comparison table or parallel narratives. Structure: stakeholder name, their rights, their obligations, how they are protected.
- Provision-by-Provision: structured sections in document order. Structure: section name, what it says, who it applies to, notable details.
- Risk & Asymmetry: bullet points or short sections. Structure: risk or asymmetry name, which party it favors, why it matters, whether it is absolute or qualified.
- Comparison: side-by-side table or section-by-section. Structure: topic, version 1, version 2, implications of the change.

---

## QUALITY CHECK BEFORE DELIVERY

For any approach:
1. No interpretation: describe what it says, not what it means legally.
2. No advice: no "you should," "you must," "avoid."
3. No judgment: no "unfair," "predatory," "suspicious."
4. Plain language: a layman could understand it without a legal background.
5. Complete: all journeys, stakeholders, or provisions covered.
6. Flagged conflicts: all contradictions noted.
7. Caveats included: the reader knows what the analysis is not.
8. Source-checked: every fact in the output comes from the current document.

If any check fails, revise before delivering.
