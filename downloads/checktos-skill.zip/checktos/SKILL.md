---
name: checktos
description: Analyze a product's terms of service, terms of use, privacy policy, or any binding agreement from a URL or a file. Covers the whole document set, not just the front page: it discovers and reads every linked binding document (privacy policy, acceptable use policy, SMS terms, data processing addendum, and any separate product or master agreement), and when a product is governed by more than one distinct agreement it produces a separate full breakdown for each. Each breakdown is a faithful extraction plus a plain-language analysis organized into four journeys (Product, Usage, Feedback & Improvement, Legal Ramifications), a factual clarity read, and an evidence-backed structure summary. Use when someone wants to understand what a product's terms actually say before agreeing, check a specific product's terms in full, or produce a CheckTOS directory entry. Triggers on "check this TOS", "analyze these terms", "what do these terms say", "read the terms for me", or a pasted terms/privacy URL.
---

# CheckTOS

Turn a product's terms into a faithful extraction plus a plain-language analysis, without judging the company. You quote the document and translate it; the reader draws their own conclusions.

Two things make a CheckTOS read comprehensive rather than shallow:

1. **You read the whole binding set, not just the page you were handed.** A terms-of-service page almost always incorporates other documents by reference: a privacy policy, an acceptable use policy, SMS terms, a data processing addendum, additional terms. The clauses that matter most to a person, especially how their data is used and whether it trains models, frequently live in those linked documents, not the main one. You find them, read them, and fold them in.
2. **When a product is governed by more than one agreement, you break down each one.** Some products put the website under a Terms of Use and the actual product under a separate Master Customer Agreement or product agreement. Those are two different things a person signs. You produce a separate full read for each, and the site presents them as a switcher.

The default outcome is **full scope**. You only fall short of it when a binding document is genuinely not reachable (behind a login, gated, unpublished), and then you say so plainly.

## What you produce

Every run emits three things:

1. `extraction.md` — the faithful extraction of **every document you consumed**, each labelled, in source order. Downloadable on its own.
2. `analysis.md` — the plain-language analysis. **One breakdown per distinct read (term-set).** Downloadable on its own.
3. `manifest.json` — the machine-readable record the CheckTOS site ingests. Its exact shape is in `output-schema.md`; follow it precisely. It holds an array of reads; when there is more than one, the site renders a switcher between them.

The extraction and the analysis stand alone. Neither is locked behind the other.

Alongside the files, you **return the breakdown inline as plain Markdown in your reply**. This is the self-contained wall of text a calling agent shows its user directly, in a chat window or any interface of its choosing. It renders from the same manifest, so the files, the site, and the inline breakdown never disagree. A human who invoked the skill reads it in the reply; an agent that invoked the skill forwards it to its own user. Its exact shape is in **The breakdown you return** below. Plain Markdown only, no HTML and nothing interactive, so it renders anywhere.

## The rules you follow

Do not restate the guideline files; read them and apply them in full.
- Extraction obeys `guidelines/document-extraction-standards.md`, with `guidelines/extraction-guidelines.md` routing the conditional handling (visual content, uncertainty, scope, provenance).
- Analysis obeys `guidelines/analysis-guidelines.md`, with `guidelines/analysis-decision-tree.md` for approach when a document is not a standard TOS.

The hard lines, restated because they govern everything:

- **No interpretation, no advice, no speculation, no gap-filling, no moral judgment.** You never call a company or a clause "shady," "unfair," or "predatory." You state what a clause says, quote it, and flag its structure (one-sided, absolute, undefined, contradictory, missing).
- **Every quote, number, section citation, defined term, date, and party name comes only from the documents you are reading right now.** Nothing carries over from an example or a previous run.
- **Never fabricate and never bypass a gate.** If a document is behind a login, a paywall, or a bot check, you do not invent its contents and you do not try to get around the protection. You record it as not reached, with the reason, and the read stays partial for that piece.

## Pipeline

### Step 1: Get the input
If the user has not given you a URL or a file, ask for the URL and wait. Do not guess a URL, and do not analyze from memory; every run fetches the source fresh.
- For a URL: fetch the current page and record the retrieval date. Read the rendered text, not the raw HTML. If a summarizing fetch paraphrases or refuses to reproduce legal text, pull the raw document so your quotes are verbatim.
- For a file or pasted text: read it as provided.
- Capture the source, document title, entity name, the "last revised" or effective date, and any version identifier.

### Step 2: Map the full document set
Before extracting, find everything that binds the user, not just the page in front of you.
- Read the main document for every incorporated or linked binding document: privacy policy / privacy notice, acceptable use policy, SMS or messaging terms, cookie policy, data processing addendum, additional terms, exhibits, platform or community rules.
- Check whether the actual product runs on a **separate agreement** from the page you were given. A website Terms of Use often points to a Master Customer Agreement, a product agreement, a subscription agreement, or an order form for the real product. Look for it on the site's legal or terms area even when the main page does not link it directly.
- Fetch each document that is publicly reachable and read it. Record, for each: name, URL, and its own revised/effective date.
- For anything you cannot reach (login-gated, unpublished, a per-customer order form, a 404), record it as not reached with the reason. Do not infer its contents.

### Step 3: Group the documents into reads
Decide how many distinct term-sets a person actually faces. This decides how many breakdowns you write.
- **One read** is the common case: a single agreement (with its privacy policy and other sub-documents folding into it).
- **Two or more reads** when separate agreements govern separate things, for example a website Terms of Use and a separate product / Master Customer Agreement. Each becomes its own full read.
- Sub-documents (privacy policy, acceptable use policy, SMS terms, data processing addendum) are **not** their own reads. They fold into the read they support: the privacy policy and DPA feed the read whose data they govern, the acceptable use policy feeds the read that points to it.
- Give each read a short label the reader will see (for example "Product terms" and "Website terms") and mark which one is primary, usually the agreement that governs the actual product.

### Step 4: For each read, extract and analyze
Run the full pipeline once per read, over that read's whole document set.
- **Extract** every document in the read against the standards file: faithful text in source order, a metadata block, and a flags section (contradictions, undefined terms, cross-reference issues, and the rest, each with exact text and section).
- **Analyze into the four journeys.** Sort the read's provisions, from the main document and from its linked documents, into the four fixed journeys. A provision can appear in more than one. For each journey, write a plain-language explanation, quote the clauses it rests on with their sources, note qualifiers and conditions, and name what the documents do not address.
  - **Product** — what the product is and does per the terms; what you are licensed to do; who owns the service and what you create with it; payment and refund terms.
  - **Usage** — how you may and may not use it; account rules; acceptable use; what you grant over your inputs, data, and connected accounts.
  - **Feedback & Improvement** — how feedback and suggestions are treated; whether your data trains their models; usage and telemetry data; beta terms. This is where the privacy policy usually changes the picture, so read it here with care.
  - **Legal Ramifications** — arbitration and class-action waivers and any opt-out; liability caps; indemnification; unilateral changes; termination and survival; governing law.
- **Write the lead.** One plain `headline`: the single most consequential fact of this read, stated without judgment. Then three to five `takeaways`, ranked most-consequential first, each a plain statement of what actually affects the reader. This is the fast read, and it must stand on its own if that is all someone sees.
- **Clarity read.** A factual readability read of that read's documents, not a judgment of the company. Base it only on measurable signals: length, density of defined terms, average sentence length or reading level, number of all-caps blocks, and how far the important clauses (arbitration, liability, data, termination) sit from the top. Map to one band: Easy, Moderate, Hard, or Very hard to understand. "Hard to read" is a fact about the document and is safe to publish.
- **Structure summary.** Count and name the structural flags the analysis surfaced, each tied to a quote and a section: contradictions, undefined terms carrying weight, one-sided provisions, absolute statements, scope limitations, and gaps. Evidence, not a verdict. It replaces any "shadiness" score. Never total these into a grade of the company.

### Step 5: Decide scope, honestly
- A **read is full** when every binding document it depends on was reached and folded in. It is **partial** when a document it depends on is named but not reached; then name that document and the reason.
- The **product is full scope** when every read is full and no separate term-set was left unreachable. It is partial otherwise. For a product where the real terms sit in a gated agreement you could not reach, partial is the correct and honest result; do not force it to full.

### Step 6: Pull the contact routes
From every document, collect each way to reach the company, and route it by what a person would need it for. This is reference the reader can act on, never an action you take.
- Categories: privacy and data requests (a privacy email, a data protection officer, a regulatory or DSA contact point); support or billing; legal notice or dispute (the attention line and postal address); and the arbitration opt-out, with its exact channel and deadline.
- Take each value verbatim from a document and record its source. Do not invent a channel the documents do not give.
- The breakdown displays these and, if the user asks, drafts a message for them. It never sends anything. Emailing, messaging, or mailing the company is the user's own action, taken by them, and CheckTOS does not do it on their behalf.

### Step 7: Name the company by its brand
So the reader is never confused about who is speaking, and so CheckTOS never reads as if it represents the company, normalize the company's self-reference:
- In the analysis and in the quotes as they appear in the breakdown, render the company's reference to itself as the plain product or brand name (for example "Instinct", "Lovable", "TypeSafe"), not the first person ("we", "us", "our") and not a generic label ("the Company", "the Company Entities"). Inside an all-caps block, use the brand in caps to match.
- Keep `extraction.md` fully verbatim, including the original "we/us/our". The normalization is a readability convention for the analysis only, and the caveats disclose it.
- This is a substitution of the speaker, never a change to the substance of a clause. If a swap would distort meaning, quote it straight instead.

### Step 8: Write the caveats
Every read's caveats block states, plainly:
- What the analysis is **not**: not legal advice, no reading of the law, no view on whether a clause would hold up, no prediction of what happens if you break the terms, no judgment of the company.
- **Every source it rests on, by name and date**, and the date you read them. List the main document and each linked document you folded in (privacy policy, acceptable use policy, SMS terms, data processing addendum, and so on).
- The **final scope**: whether this covers the full binding set or remains partial, and if partial, exactly what is still outside it.
- The **brand-normalization** note: that the company's self-references are shown as the brand name for clarity, and that the downloadable extraction keeps the original wording.

### Step 9: Write the outputs
- `manifest.json` to the schema in `output-schema.md`: product-level metadata plus the `reads` array, one entry per read, each with its own meta, clarity, journeys, structure summary, and caveats.
- `extraction.md`: every consumed document, labelled, in source order, with the flags and cross-reference sections.
- `analysis.md`: one rendered breakdown per read. When there is more than one read, note that the site shows them behind a switcher, primary read first.
- Date-stamp everything against the versions you read, so any later correction is a factual fix.

## The breakdown you return

Return this in your reply as plain Markdown, rendered from the manifest. Lead with the fast read (headline and takeaways), then the detail, so a person or an agent can stop at the top or read on. A product with more than one read repeats the per-read block under each read's label, primary read first, after a one-line note that more than one agreement governs the product. Contacts and the overall caveats sit once at the end, since they are product-wide.

```
# {Product name}
{One line: what the product is and who it is for.} · Read on {retrieval date}. Scope: {full | partial}.
{If more than one read: "Two agreements govern this: {read labels}. The primary read is {label}."}

## {Read label}          ← omit this heading when there is only one read

**Clarity: {band}.** {clarity statement}

**{headline}**
1. {takeaway, most consequential first}
2. {takeaway}
3. {takeaway}

### Product
{plain summary}
> "{verbatim quote}" — {source · section}

_Missing: {what the documents do not address in this journey.}_

### Usage
{…summary, quotes, missing, as above…}

### Feedback & improvement
{…}

### Legal ramifications
{…}

**Structure flags** — one-sided ({n}), absolute ({n}), undefined terms ({n}), scope limits ({n}), gaps ({n}), contradictions ({n}). Each is quoted and located in full below the counts.

## How to reach them
- **Privacy and data** — {value} ({source})
- **Support** — {value}
- **Legal notice** — {verbatim attention line and address}
- **Arbitration opt-out** — {channel and deadline}

_You send these yourself. The breakdown lists the routes and will draft a message on request; it never sends anything._

## Caveats
{What this is not (no legal advice, no reading of the law, no view on enforceability, no prediction, no judgment). Every source by name and date, and the date read. The final scope. The note that company self-references are shown as the brand name for clarity, while the downloadable extraction keeps the original wording.}
```

Keep it plain: no tables, no HTML, no collapsible sections. Quotes stay verbatim and keep their source and section.

## Output discipline

- `manifest.json` must validate against `output-schema.md` exactly. The site depends on it.
- The default is full scope. Mark a read `partial` only when a binding document it depends on was genuinely not reached, and name it.
- If you cannot fully extract a document (corrupted, image-only, unclear OCR), say so and flag it; do not work around it.
- Verbatim is non-negotiable: every quote in the output appears word-for-word in its source. Check each one back against the fetched text before you finish.

## Files in this skill

- `SKILL.md` — this file.
- `output-schema.md` — the output contract, including the multi-read `reads` array.
- `guidelines/` — the four rule files this skill reads: `document-extraction-standards.md`, `extraction-guidelines.md`, `analysis-guidelines.md`, `analysis-decision-tree.md`.
