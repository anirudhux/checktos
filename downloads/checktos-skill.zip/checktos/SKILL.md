---
name: checktos
description: Analyze a terms of service, terms of use, privacy policy, or similar agreement from a URL or a file. Produces two things: a faithful extraction of the document, and a plain-language analysis organized into four journeys (Product, Usage, Feedback & Improvement, Legal Ramifications) with a clarity read and an evidence-backed structure summary. Use when someone wants to understand what a TOS actually says before agreeing to it, check a specific product's terms, or produce a CheckTOS directory entry. Triggers on "check this TOS", "analyze these terms", "what does this terms of service say", "read the terms for me", or a pasted terms/privacy URL.
---

# CheckTOS

Turn a terms-of-service document into a faithful extraction plus a plain-language analysis, without judging the company. You quote the document and translate it; the reader draws their own conclusions.

## What you produce

Every run emits three things, in this order:
1. `extraction.md` — the faithful extracted document. Downloadable on its own.
2. `analysis.md` — the plain-language analysis with the four journeys. Downloadable on its own.
3. `manifest.json` — the machine-readable record that both of the above are rendered from. This is the format the CheckTOS site ingests. Its exact shape is defined in `output-schema.md`; follow it precisely.

The extraction and the analysis stand alone. Neither is locked behind the other.

## The rules you follow

Do not restate the guideline files; read them and apply them in full.
- Extraction obeys `guidelines/document-extraction-standards.md`, with `guidelines/extraction-guidelines.md` routing the conditional handling (visual content, uncertainty, scope, provenance).
- Analysis obeys `guidelines/analysis-guidelines.md`, with `guidelines/analysis-decision-tree.md` for approach when a document is not a standard TOS.

The hard line from those files, restated because it governs everything: no interpretation, no advice, no speculation, no gap-filling, and no moral judgment. You never call a company or a clause "shady," "unfair," or "predatory." You state what a clause says, quote it, and flag its structure (one-sided, absolute, undefined, contradictory, missing).

Every quote, number, section citation, defined term, date, and party name in your output comes only from the document you are analyzing right now. Nothing carries over from an example or a previous run.

## Pipeline

### Step 1: Get the input
Before anything else, you need the document to analyze. If the user has not given you a URL or a file, ask for the URL and wait for it. Do not guess a URL, and do not analyze from memory of a document you have seen before; every run fetches the source fresh at run time.
- For a URL: fetch the current page and record the retrieval date. Read the rendered text, not the raw HTML.
- For a file or pasted text: read it as provided.
- Capture the source, the document title, the entity name, the "last revised" or effective date, and any version identifier into the manifest metadata.

### Step 2: Detect scope
Before extracting, decide whether this page is the whole agreement or only part of it.
- If the document governs a website only and hands the product terms to a separate agreement, or incorporates binding documents by reference (privacy policy, additional terms, exhibits) that are not present, mark `scope` as `partial` in the manifest and list every referenced-but-absent document.
- If instructed and able, fetch the linked binding documents and extract each separately. Otherwise state that they are referenced but not extracted. Never infer their contents.

### Step 3: Extract
Run the extraction against the standards file. Produce `extraction.md`: the faithful text in the document's own order, plus a metadata block and a flags section (contradictions, undefined terms, cross-reference issues, and the rest, each with the exact text and section number).

### Step 4: Analyze into the four journeys
Sort the document's provisions into the four fixed CheckTOS journeys. A provision can appear in more than one. For each journey, write a plain-language explanation, quote the clauses it rests on with their section numbers, note qualifiers and conditions, and name what the document does not address.

- **Product TOS** — what the product is and does per the terms; what you are licensed to do; who owns the service and what you create with it; payment and refund terms.
- **Usage TOS** — how you may and may not use it; account rules; acceptable use; what you grant over your inputs, data, and connected accounts.
- **Feedback & Improvement TOS** — how feedback and suggestions are treated; whether your data trains their models; usage data; beta terms.
- **Legal Ramifications** — arbitration and class-action waivers; liability caps; indemnification; unilateral changes; termination and survival; governing law.

### Step 5: Clarity read
Produce a factual readability read of the document, not a judgment of the company. Base it only on measurable signals: length, density of defined terms, average sentence length or reading level, number of all-caps blocks, and how far the important clauses (arbitration, liability, data, termination) sit from the top. Map those to one band: Easy, Moderate, Hard, or Very hard to understand. "Hard to read" is a fact about the document and is safe to publish.

### Step 6: Structure summary
Count and name the structural flags the analysis surfaced, each tied to a quote and a section: contradictions, undefined terms carrying weight, one-sided provisions, absolute statements, scope limitations, and gaps. This is evidence, not a verdict. It replaces any "shadiness" score. Never total these into a grade of the company.

### Step 7: Write the outputs
Render `analysis.md` from the journeys, the clarity read, the structure summary, and a caveats block stating what the analysis is not. Write `manifest.json` to the schema. Date-stamp both against the document version you read, so any correction is a factual fix.

## Output discipline

- `manifest.json` must validate against `output-schema.md` exactly. The site depends on it.
- Mark the run `partial` whenever binding content sits outside what you extracted.
- If you cannot fully extract a document (corrupted, image-only, unclear OCR), say so and flag it; do not work around it.

## Files in this skill

- `SKILL.md` — this file.
- `output-schema.md` — the output contract.
- `guidelines/` — the four rule files this skill reads: `document-extraction-standards.md`, `extraction-guidelines.md`, `analysis-guidelines.md`, `analysis-decision-tree.md`.
