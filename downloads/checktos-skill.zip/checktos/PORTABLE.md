# CheckTOS — portable instructions

A self-contained spec for reading a product's terms of service the CheckTOS way, on any agent framework. It is the same pipeline as the Claude skill (`SKILL.md`) with the Claude-specific packaging removed. Any capable model that can fetch a URL, follow a multi-step process, and emit Markdown and JSON can run it. The inline breakdown carries a decision-inputs block so an agent can decide whether the product clears its user's own risk parameters, region, and org policy before using it. CheckTOS supplies the facts and assigns no risk level; the agent applies the user's rules.

## Setup on a non-Claude framework
- A Claude runtime auto-loads `SKILL.md` when a terms-of-service request appears. Elsewhere, provide this file as the agent's instructions and wire your own trigger: a tool the agent can call, a router rule, or a line in the system prompt for when a user pastes terms or asks to check a TOS.
- The four rule files in `guidelines/` (`document-extraction-standards.md`, `extraction-guidelines.md`, `analysis-guidelines.md`, `analysis-decision-tree.md`) hold the detailed extraction and analysis method. Load them into the agent's context if your framework can; if not, this file restates the non-negotiable rules so the pipeline still holds when run alone.
- The output contract is `output-schema.md`. The manifest the agent writes must match it.

## The rules that govern everything
- **Faithful.** Every quote, number, section citation, date, and party name comes only from the documents read in this run. Each quote is word-for-word from its source; verify every one against the fetched text before finishing. If a fetch paraphrases or refuses to reproduce legal text, pull the raw document.
- **No judgment.** Never call a company or clause shady, unfair, or predatory. State what a clause says, quote it, and flag its structure (one-sided, absolute, undefined, contradictory, missing).
- **No fabrication, no gate-bypass.** If a document sits behind a login, a paywall, or a bot check, do not invent its contents and do not try to get around the protection. Record it as not reached, with the reason.
- **No sending.** Surface the contact routes and draft a message if the user asks. Never email, message, or file anything. Sending stays the user's own action.
- **Name the company by its brand.** In the analysis and its quotes, render the company's reference to itself as the plain brand name (not "we/us/our", not "the Company"); in an all-caps block, use the brand in caps. Keep the extraction verbatim, including the original wording. This substitutes the speaker, never the substance; if a swap would distort meaning, quote it straight.
- **Full scope by default.** Read the whole binding set. Go partial only when a binding document is genuinely gated or unpublished, and say so.

## Pipeline

1. **Get the input.** If the caller provides a URL or file (for example `/checktos <URL>`, or one passed in by an agent), start immediately. If nothing is provided, ask and wait. Fetch fresh; do not work from memory. Record the source, title, entity, revised/effective date, and retrieval date.
2. **Map the full document set.** From the main document, find every incorporated or linked binding document: privacy policy, acceptable use policy, SMS terms, cookie policy, data processing addendum, additional terms, exhibits, platform rules. Check whether the real product runs on a separate agreement (a master or product agreement, a subscription agreement) even when the main page does not link it. Fetch each reachable document and record its own date. Record anything unreachable, with the reason.
3. **Group the documents into reads.** One read for a single agreement (its sub-documents fold in). Two or more when separate agreements govern separate things (a website Terms of Use and a separate product agreement). Sub-documents (privacy, acceptable use, SMS, DPA) fold into the read they support. Label each read and mark the primary one.
4. **For each read, extract and analyze.** Extract every document faithfully in source order with a flags section. Write the lead: one plain `headline` (the single most consequential fact) and three to five ranked `takeaways`, most consequential first. Sort provisions into the four journeys — Product, Usage, Feedback & Improvement, Legal Ramifications — each a plain summary with verbatim quotes carrying source and section, plus what the documents do not address. Do a factual clarity read (length, defined-term density, sentence length or reading level, all-caps blocks, how deep the key clauses sit) mapped to Easy, Moderate, Hard, or Very hard. Write a structure summary: contradictions, undefined terms, one-sided provisions, absolute statements, scope limits, and gaps, each quoted and located, none totalled into a score. Pull the decision inputs the calling agent needs to make a use-or-not call against its user's own rules, on three axes: region (governing law, venue, where data is processed or stored, cross-border transfer, residency options, region-specific rights such as GDPR or CCPA), org (third-party sharing, subprocessors disclosed, DPA offered, security or compliance claims, confidentiality, whether user data trains models, who owns your inputs and outputs), and risk (arbitration and any class-action waiver and opt-out, liability cap, indemnification you owe, unilateral changes, termination or suspension, content license granted). Each value is verbatim or a plain factual summary with its source, and null when unaddressed; CheckTOS assigns no risk level.
5. **Decide scope honestly.** A read is full when every binding document it depends on was reached; partial otherwise, and then name what is missing. The product is full when every read is full and no term-set was left unreached.
6. **Pull the contact routes.** Collect every way to reach the company and route it by purpose: privacy and data (a privacy email, a data protection officer, a regulatory or DSA contact), support, legal notice (attention line and address), and the arbitration opt-out with its exact channel and deadline. Take each value verbatim with its source. Display only; never send.
7. **Name the company by its brand** (see the rules above).
8. **Write the caveats.** For each read: what the analysis is not (no legal advice, no reading of the law, no view on enforceability, no prediction, no judgment); every source by name and date, and the date read; the final scope; and the brand-normalization note.
9. **Produce the outputs.** Write `manifest.json` to `output-schema.md`; write `extraction.md` (every document, labelled, in source order) and `analysis.md` (one breakdown per read). Then return the breakdown inline as plain Markdown, using the template below, so a calling agent can show it to its own user directly. Also render the full breakdown into `breakdown-template.html` (shipped alongside this file) and write it as `<product>-breakdown.html`: a standalone styled page with the CSS and the product image inlined so it opens anywhere. Get the image from the source page's `og:image` meta tag (fall back to `apple-touch-icon` or the favicon, then to no image) and inline it as a base64 `data:` URI; never screenshot or bypass a bot check. Point the "Go to source" link at the terms URL. Keep the disclosed usage beacon and its visible footer note: it pings CheckTOS once on open, sends nothing about the document, the company, or the user, and is silent offline. Open the page when the framework can; otherwise report its path.

## The breakdown you return

Return this as plain Markdown, rendered from the manifest. Lead with the fast read, then the detail. A product with more than one read repeats the per-read block under each read's label, primary first, after a one-line note that more than one agreement governs it. Contacts and caveats sit once at the end.

```
# {Product name}
{One line: what the product is and who it is for.} · Read on {retrieval date}. Scope: {full | partial}.
{If more than one read: "Two agreements govern this: {read labels}. The primary read is {label}."}

## {Read label}          ← omit when there is only one read

**Clarity: {band}.** {clarity statement}

**{headline}**
1. {takeaway, most consequential first}
2. {takeaway}
3. {takeaway}

**Decision inputs** — the facts your policy weighs, so the takeaways above become a go or no-go. CheckTOS assigns no risk level; you apply your own rules.
- Region: governing law {…}; venue {…}; data processed in {…}; residency options {…}; region-specific rights {…}.
- Org: third-party sharing {…}; subprocessors disclosed {…}; DPA {…}; security or compliance claims {…}; trains on your data {…}; owns your inputs and outputs {…}.
- Risk: arbitration {…}; class-action waiver {…}; opt-out {…}; liability cap {…}; indemnity you owe {…}; unilateral changes {…}; termination {…}; content license {…}.

_Everything below is the fine print, for a person who wants it or an agent that needs to back up the call._

### Product
{plain summary}
> "{verbatim quote}" — {source · section}

_Missing: {what the documents do not address in this journey.}_

### Usage
{…summary, quotes, missing…}

### Feedback & improvement
{…}

### Legal ramifications
{…}

**Structure flags** — one-sided ({n}), absolute ({n}), undefined terms ({n}), scope limits ({n}), gaps ({n}), contradictions ({n}). Each is quoted and located below the counts.

## How to reach them
- **Privacy and data** — {value} ({source})
- **Support** — {value}
- **Legal notice** — {verbatim attention line and address}
- **Arbitration opt-out** — {channel and deadline}

_You send these yourself. The breakdown lists the routes and will draft a message on request; it never sends anything._

## Caveats
{What this is not; every source by name and date; the final scope; the note that company self-references are shown as the brand name while the extraction keeps the original wording.}
```

Keep it plain: no tables, no HTML, nothing interactive. Quotes stay verbatim with their source and section.

## Output discipline
- `manifest.json` must validate against `output-schema.md`.
- Full scope is the default; mark a read partial only when a binding document it depends on was genuinely not reached, and name it.
- If a document cannot be fully extracted (corrupted, image-only, unclear OCR), say so and flag it; do not work around it.
- Verify every quote against its source before finishing.
