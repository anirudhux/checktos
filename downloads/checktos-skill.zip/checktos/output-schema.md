# CheckTOS Output Schema

The locked output contract. Every run emits three artifacts. `manifest.json` is the machine record the CheckTOS site ingests; `extraction.md` and `analysis.md` are the two downloadable documents, both rendered from the manifest. A run that follows this schema drops straight into the directory with no re-authoring.

All values come only from the document under analysis. Any field you cannot fill from the document is set to `null` (single value) or `[]` (list), never guessed.

---

## Artifacts

- `extraction.md` — faithful extraction per `guidelines/document-extraction-standards.md`.
- `analysis.md` — plain-language analysis rendered from `manifest.json`.
- `manifest.json` — the record below.

---

## manifest.json

```json
{
  "schema_version": "1.0",
  "meta": {
    "product_name": "string",
    "entity": "string | null",
    "document_type": "terms of service | terms of use | privacy policy | other",
    "source_url": "string | null",
    "revised_date": "YYYY-MM-DD | null",
    "effective_date": "YYYY-MM-DD | null",
    "retrieval_date": "YYYY-MM-DD",
    "scope": "full | partial",
    "linked_documents": [
      { "name": "string", "url": "string | null", "extracted": true }
    ],
    "applied_sections": ["Core", "H", "I", "J", "K"]
  },

  "clarity": {
    "band": "Easy | Moderate | Hard | Very hard",
    "signals": {
      "word_count": 0,
      "defined_term_count": 0,
      "avg_sentence_length_words": 0,
      "reading_level": "string | null",
      "all_caps_blocks": 0,
      "key_clauses_depth": "string"
    },
    "statement": "One factual sentence about readability, e.g. 'Long, dense with defined terms, several all-caps blocks.' No judgment of the company."
  },

  "journeys": {
    "product": {
      "summary": "Plain-language explanation of this journey.",
      "clauses": [ { "quote": "verbatim text", "section": "e.g. Section 4" } ],
      "notable": [ "qualifier, condition, or time limit" ],
      "missing": [ "what the document does not address in this journey" ]
    },
    "usage": { "summary": "", "clauses": [], "notable": [], "missing": [] },
    "feedback_improvement": { "summary": "", "clauses": [], "notable": [], "missing": [] },
    "legal_ramifications": { "summary": "", "clauses": [], "notable": [], "missing": [] }
  },

  "structure_summary": {
    "contradictions": [
      { "quote_a": "", "section_a": "", "quote_b": "", "section_b": "" }
    ],
    "undefined_terms": [
      { "term": "", "sections": ["Section X"] }
    ],
    "one_sided": [
      { "description": "", "quote": "", "section": "" }
    ],
    "absolute_statements": [
      { "quote": "", "section": "" }
    ],
    "scope_limitations": [
      { "description": "", "section": "" }
    ],
    "gaps": [
      { "description": "" }
    ],
    "counts": {
      "contradictions": 0,
      "undefined_terms": 0,
      "one_sided": 0,
      "absolute_statements": 0,
      "scope_limitations": 0,
      "gaps": 0
    }
  },

  "caveats": "Standard limitations statement: what the analysis did not cover (no legal interpretation, no enforceability, no prediction, no advice, no judgment)."
}
```

---

## Field rules

- `meta.scope` is `partial` whenever binding content sits outside what was extracted; `linked_documents` then lists every referenced-but-absent document, with `extracted: false`.
- `meta.applied_sections` records which extraction sections ran (Core plus any conditional H–K).
- `clarity` is factual only. The band comes from the signals, not from a view of whether the terms are fair. Never phrase it as a judgment of the company.
- `journeys` always has all four keys, even when a journey is thin; an empty journey carries an explanatory `summary` and empty lists.
- `structure_summary` is evidence, not a score. Every item ties to a quote and a section (except `gaps`, which name what is absent). `counts` mirror the list lengths. Do not total them into any grade of the company.
- Every `quote` is verbatim from the document, in quotation marks in the rendered output, with its `section`.

---

## Rendering to analysis.md

Render in this order: opening statement (document type, who it is for, scope); the clarity band and its one-sentence statement; the four journeys; the structure summary as named, quoted evidence; the caveats block. Date-stamp against `meta.revised_date` and `meta.retrieval_date`.

## Rendering to extraction.md

Follow the output structure in `guidelines/document-extraction-standards.md`: metadata section, the faithful text in source order, a flags-and-conflicts section, an index of defined terms, and a cross-reference map.
