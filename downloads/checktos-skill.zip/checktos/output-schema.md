# CheckTOS Output Schema

The locked output contract. Every run emits three artifacts. `manifest.json` is the machine record the CheckTOS site ingests; `extraction.md` and `analysis.md` are the two downloadable documents, both rendered from it. A run that follows this schema drops straight into the directory with no re-authoring.

All values come only from the documents under analysis. Any field you cannot fill from a document is set to `null` (single value) or `[]` (list), never guessed.

The manifest holds an array of **reads**. A read is one distinct term-set: one agreement plus the sub-documents that fold into it. Most products have a single read. A product governed by more than one agreement (for example a website Terms of Use and a separate product / Master Customer Agreement) has one read per agreement, and the site renders a switcher between them, primary read first.

---

## Artifacts

- `extraction.md` — faithful extraction of every consumed document per `guidelines/document-extraction-standards.md`.
- `analysis.md` — plain-language analysis, one breakdown per read, rendered from `manifest.json`.
- `manifest.json` — the record below.

---

## manifest.json

```json
{
  "schema_version": "2.0",

  "product": {
    "product_name": "string",
    "entity": "string | null",
    "retrieval_date": "YYYY-MM-DD",
    "scope": "full | partial",
    "unreached": [
      { "name": "string", "reason": "login-gated | unpublished | per-customer order form | 404 | other" }
    ],
    "contacts": [
      {
        "purpose": "privacy | support | legal notice | arbitration opt-out | regulatory | other",
        "label": "string, e.g. Privacy and data",
        "channel": "email | postal | web form | phone",
        "value": "verbatim address, email, or URL from the document",
        "detail": "string | null, e.g. a deadline or an attention line, verbatim where possible",
        "source": "document + section"
      }
    ]
  },

  "reads": [
    {
      "id": "product-terms | website-terms | terms | string",
      "label": "string, e.g. Product terms",
      "primary": true,

      "meta": {
        "document_type": "terms of service | terms of use | master agreement | privacy policy | other",
        "source_url": "string | null",
        "revised_date": "YYYY-MM-DD | null",
        "effective_date": "YYYY-MM-DD | null",
        "scope": "full | partial",
        "sources": [
          { "name": "string", "url": "string | null", "revised_date": "YYYY-MM-DD | null", "extracted": true }
        ],
        "not_included": [
          { "name": "string", "reason": "string" }
        ],
        "applied_sections": ["Core", "H", "I", "J", "K"]
      },

      "clarity": {
        "band": "Easy | Moderate | Hard | Very hard",
        "signals": {
          "word_count": 0,
          "defined_term_count": 0,
          "avg_sentence_length_words": 0,
          "reading_level": "string | null",
          "all_caps_blocks": 0,
          "key_clauses_depth": "string"
        },
        "statement": "One factual sentence about readability. No judgment of the company."
      },

      "headline": "One plain sentence naming the single most important thing about this read.",
      "takeaways": [
        "Ranked, most consequential first: three to five plain statements of what actually affects the reader. This is the fast read an agent can show on its own."
      ],

      "journeys": {
        "product": {
          "summary": "Plain-language explanation of this journey for this read.",
          "clauses": [ { "quote": "verbatim text", "section": "e.g. Section 4", "source": "which document" } ],
          "notable": [ "qualifier, condition, or time limit" ],
          "missing": [ "what the documents do not address in this journey" ]
        },
        "usage": { "summary": "", "clauses": [], "notable": [], "missing": [] },
        "feedback_improvement": { "summary": "", "clauses": [], "notable": [], "missing": [] },
        "legal_ramifications": { "summary": "", "clauses": [], "notable": [], "missing": [] }
      },

      "structure_summary": {
        "contradictions": [ { "quote_a": "", "section_a": "", "quote_b": "", "section_b": "" } ],
        "undefined_terms": [ { "term": "", "sections": ["Section X"] } ],
        "one_sided": [ { "description": "", "quote": "", "section": "" } ],
        "absolute_statements": [ { "quote": "", "section": "" } ],
        "scope_limitations": [ { "description": "", "section": "" } ],
        "gaps": [ { "description": "" } ],
        "counts": {
          "contradictions": 0, "undefined_terms": 0, "one_sided": 0,
          "absolute_statements": 0, "scope_limitations": 0, "gaps": 0
        }
      },

      "caveats": "Limitations for this read: what it is not (no legal interpretation, no enforceability, no prediction, no advice, no judgment); every source by name and date; the final scope for this read; and the note that company self-references are shown as the brand name while the extraction keeps the original wording."
    }
  ]
}
```

---

## Field rules

- `reads` has one entry for a single-term-set product, and one entry per distinct agreement otherwise. Exactly one read has `primary: true`; it is usually the agreement that governs the actual product. The site shows a switcher only when `reads.length > 1`.
- `product.scope` is `full` when every read is `full` and no separate term-set was left unreached; `partial` otherwise. `product.unreached` names any whole term-set (for example a gated product agreement) that could not be reached, with the reason.
- `product.contacts` lists every route to reach the company that appears in the documents, routed by `purpose`: privacy and data requests, support, legal notice, arbitration opt-out (put its deadline in `detail`), and regulatory contacts such as a DSA contact point. Each `value` is verbatim from a document, with its `source`. It is reference only: the breakdown surfaces it, and on request drafts a message, but it never sends anything. Sending stays the user's own action.
- Each read's `meta.scope` is `full` when every binding document it depends on was reached and folded in, `partial` when one is named but not reached. `meta.sources` lists every document consumed for that read (main plus linked: privacy policy, acceptable use policy, SMS terms, data processing addendum, and so on), each with `extracted: true` and its own date. `meta.not_included` lists documents this read depends on that were not reached, with the reason.
- `meta.applied_sections` records which extraction sections ran (Core plus any conditional H–K).
- `clarity` is factual only. The band comes from the signals, not from a view of whether the terms are fair. Never phrase it as a judgment of the company.
- `headline` is one plain sentence: the single most consequential fact of the read, stated without judgment. `takeaways` are three to five, ranked most-consequential first, each a plain statement of what affects the reader. Together they are the lead the breakdown opens with, so the fast read stands on its own before the detail.
- `journeys` always has all four keys, even when a journey is thin; an empty journey carries an explanatory `summary` and empty lists. Each clause carries the `source` document it came from, so a folded-in privacy or acceptable-use quote is traceable.
- `structure_summary` is evidence, not a score. Every item ties to a quote and a section (except `gaps`, which name what is absent). `counts` mirror the list lengths. Do not total them into any grade of the company.
- Every `quote` is verbatim from its source document. In the rendered breakdown, the company's self-reference is shown as the brand name (in caps inside an all-caps block); the substitution is disclosed in `caveats` and `extraction.md` keeps the original wording.

---

## Rendering to analysis.md

Render one breakdown per read, primary read first, with a visible label per read and a note that the site presents multiple reads behind a switcher. Within a read, render in this order: an opening line (document type, who it is for, scope); the clarity band and its one-sentence statement; the four journeys; the structure summary as named, quoted evidence; the caveats block. Date-stamp against the read's `revised_date` and the `retrieval_date`.

## Rendering to extraction.md

Follow the output structure in `guidelines/document-extraction-standards.md`. Cover every consumed document, each under its own labelled heading in source order, each with its metadata, faithful text, flags-and-conflicts section, defined-term index, and cross-reference map.
